#! /bin/bash
ssh 192.168.1.224 -p 6969 './remote.sh'