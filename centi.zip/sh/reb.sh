#!/bin/bash
sudo reboot
