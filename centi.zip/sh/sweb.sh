#!/bin/bash
fswebcam -r 1920x1080 $HOME/.dominae/img/sweb.png -q
