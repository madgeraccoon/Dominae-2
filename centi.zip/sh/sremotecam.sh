#! /bin/bash
ssh 192.168.1.197 -p 666 './remotecam.sh'