#!/bin/bash
sudo pacman -Syu --noconfirm
