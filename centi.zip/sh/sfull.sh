#!/bin/bash
scrot ~/.dominae/img/sfull.png
