#!/bin/bash
scrot -u $HOME/.dominae/img/swindow.png -d 3
