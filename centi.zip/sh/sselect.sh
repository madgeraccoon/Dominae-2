#!/bin/bash
scrot -s $HOME/.dominae/img/sselect.png
